#!/bin/bash
PROBLEM=$1

cd $PROBLEM
tps gen
docker exec -it cws /usr/local/bin/cmsImportTask -S -L tps_task /Problem-2022/$PROBLEM --update
