def height_limit(M: int) -> int:
    from __main__ import is_broken
    if is_broken(2) == 1:
        return 1
    return 2
