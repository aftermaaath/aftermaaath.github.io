#ifndef EGG_H_
#define EGG_H_

long long height_limit(long long M);

int is_broken(long long k);

#endif // EGG_H_
