#include <iostream>
using namespace std;

int main() {
	//This is model solution
}
